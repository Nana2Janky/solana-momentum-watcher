SOLANA MOMENTUM WATCHER — IPHONE EDITION
=========================================

What this is
------------
A mobile-friendly web app that reads public DexScreener market data, scores a
small sample of Solana tokens using simple heuristics, and records paper trades
in the browser. It does NOT connect to a wallet or place real orders.

Files
-----
- index.html: the app. Open it from a static website host to use it in Safari.
- README.txt: setup instructions.

Free iPhone setup (recommended: GitHub Pages)
---------------------------------------------
You need a GitHub account. This can be done from Safari on your iPhone.

1. Go to https://github.com and create/sign into an account.
2. Create a NEW PUBLIC repository named exactly: solana-momentum-watcher
3. Choose "Add file" -> "Upload files".
4. Upload index.html from this folder. You may also upload README.txt.
5. Commit the files to the main branch.
6. In the repository, open Settings -> Pages.
7. Under "Build and deployment", choose "Deploy from a branch".
8. Select branch "main", folder "/ (root)", then Save.
9. Wait for GitHub Pages to publish. The URL should be:
   https://YOUR-GITHUB-USERNAME.github.io/solana-momentum-watcher/
   Replace YOUR-GITHUB-USERNAME with your actual GitHub username.
10. Open that URL in Safari. Tap Share -> Add to Home Screen -> Add.

If uploading files on iPhone is awkward, open the repository in Safari and use
the desktop website option. Do not paste secrets into this app; it needs none.

How to use
----------
- Tap Scan tokens. The app checks the latest public DexScreener profile and
  boost lists, then looks up up to 35 candidate tokens.
- Token cards show a heuristic score, liquidity, volume, price change, and
  recent buys/sells. Scores are not buy recommendations or safety ratings.
- "Paper buy" only creates a simulated position. It does not buy crypto.
- Paper positions/history/settings are stored in Safari local storage on this
  device/browser. Export regularly if you want a backup.
- Auto-scan attempts to scan every minute only while the page is open. iOS may
  pause background tabs; this is not a continuously running server.
- Adjust thresholds in Settings.

Important limitations
---------------------
- Discovery lists are incomplete and this checks only a small sample.
- Public market data may be delayed, manipulated, or missing.
- The app cannot confirm holder concentration, token mint/freeze authority,
  wallet distribution, or whether a project is legitimate.
- A token can still be a rug even with high liquidity or a high score.
- Browser/API access or rate limits may prevent scans from working. If that
  happens, retry later. Do not enter a wallet seed phrase or private key.
- Simulated fills/slippage/fees are approximations and do not prove a strategy
  would be profitable live.
- No alerts run while Safari is closed. A free always-on scanner would require
  a server or automation host, and free-tier limits can change.

Data endpoint documentation: https://docs.dexscreener.com/
Static hosting docs: https://docs.github.com/pages
